__version__ = u'10.0.1'
__openstackrelease__ = u'newton'
